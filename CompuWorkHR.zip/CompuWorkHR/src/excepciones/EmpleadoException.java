/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package excepciones;

public class EmpleadoException extends Exception {
    public EmpleadoException(String mensaje) {
        super(mensaje);
    }
}