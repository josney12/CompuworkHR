/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package excepciones;

/**
 * Excepción personalizada para manejar errores relacionados con la gestión de departamentos
 */
public class DepartamentoException extends Exception {
    
    /**
     * Constructor con mensaje personalizado
     * @param mensaje Descripción del error ocurrido
     */
    public DepartamentoException(String mensaje) {
        super(mensaje);
    }
    
    /**
     * Constructor con mensaje y causa del error
     * @param mensaje Descripción del error
     * @param causa Excepción original que causó el error
     */
    public DepartamentoException(String mensaje, Throwable causa) {
        super(mensaje, causa);
    }
}
