/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package servicios;

import interfaces.IGestionDepartamentos;
import java.util.ArrayList;
import java.util.List;
import modelo.Departamento;
import excepciones.DepartamentoException;

public class GestionDepartamentosImpl implements IGestionDepartamentos {
    private List<Departamento> departamentos;
    private int nextId;
    
    public GestionDepartamentosImpl() {
        this.departamentos = new ArrayList<>();
        this.nextId = 1;
    }

    @Override
    public void crearDepartamento(Departamento departamento) throws DepartamentoException {
        if (departamento == null) {
            throw new DepartamentoException("El departamento no puede ser nulo");
        }
        
        if (departamento.getNombre() == null || departamento.getNombre().trim().isEmpty()) {
            throw new DepartamentoException("El nombre del departamento es requerido");
        }
        
        // Verificar si ya existe un departamento con el mismo nombre
        boolean nombreExiste = departamentos.stream()
                .anyMatch(d -> d.getNombre().equalsIgnoreCase(departamento.getNombre()));
        
        if (nombreExiste) {
            throw new DepartamentoException("Ya existe un departamento con ese nombre");
        }
        
        departamento.setId(nextId++);
        departamentos.add(departamento);
    }

    @Override
    public void eliminarDepartamento(int id) throws DepartamentoException {
        Departamento dep = buscarDepartamento(id);
        
        // Verificar si el departamento tiene empleados
        if (!dep.getEmpleados().isEmpty()) {
            throw new DepartamentoException("No se puede eliminar un departamento con empleados asignados");
        }
        
        departamentos.remove(dep);
    }

    @Override
    public Departamento buscarDepartamento(int id) throws DepartamentoException {
        return departamentos.stream()
                .filter(d -> d.getId() == id)
                .findFirst()
                .orElseThrow(() -> new DepartamentoException("Departamento no encontrado con ID: " + id));
    }

    @Override
    public List<Departamento> listarDepartamentos() {
        return new ArrayList<>(departamentos);
    }

    @Override
    public void actualizarDepartamento(Departamento departamento) throws DepartamentoException {
        if (departamento == null) {
            throw new DepartamentoException("El departamento no puede ser nulo");
        }
        
        Departamento existente = buscarDepartamento(departamento.getId());
        
        // Verificar si el nuevo nombre ya existe (excepto para este departamento)
        boolean nombreExiste = departamentos.stream()
                .filter(d -> d.getId() != departamento.getId())
                .anyMatch(d -> d.getNombre().equalsIgnoreCase(departamento.getNombre()));
        
        if (nombreExiste) {
            throw new DepartamentoException("Ya existe otro departamento con ese nombre");
        }
        
        existente.setNombre(departamento.getNombre());
        existente.setDescripcion(departamento.getDescripcion());
    }
}