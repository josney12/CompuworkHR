/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package servicios;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import modelo.Evaluacion;
import modelo.ReporteDesempeño;
import modelo.Empleado;
import excepciones.EmpleadoException;
import java.util.stream.Collectors;


public class ReporteService {
    private List<ReporteDesempeño> reportes;
    private int nextId;
    
    public ReporteService() {
        this.reportes = new ArrayList<>();
        this.nextId = 1;
    }
    
    public ReporteDesempeño crearReporte(Empleado empleado, Date fechaEvaluacion, 
                                       String comentariosGenerales) throws EmpleadoException {
        if (empleado == null) {
            throw new EmpleadoException("El empleado no puede ser nulo");
        }
        
        ReporteDesempeño reporte = new ReporteDesempeño(nextId++, empleado, fechaEvaluacion, comentariosGenerales);
        reportes.add(reporte);
        return reporte;
    }
    
    public void agregarEvaluacion(ReporteDesempeño reporte, Evaluacion evaluacion) {
        reporte.agregarEvaluacion(evaluacion);
    }
    
    public List<ReporteDesempeño> generarReportesIndividuales(Empleado empleado) {
        return reportes.stream()
                .filter(r -> r.getEmpleado().equals(empleado))
                .collect(Collectors.toList());
    }
    
    public List<ReporteDesempeño> generarReportesDepartamentales(int idDepartamento) {
        return reportes.stream()
                .filter(r -> r.getEmpleado().getDepartamento() != null && 
                           r.getEmpleado().getDepartamento().getId() == idDepartamento)
                .collect(Collectors.toList());
    }
    
    public double calcularPromedioDepartamento(int idDepartamento) {
        List<ReporteDesempeño> reportesDep = generarReportesDepartamentales(idDepartamento);
        
        if (reportesDep.isEmpty()) return 0;
        
        double suma = 0;
        int count = 0;
        
        for (ReporteDesempeño reporte : reportesDep) {
            suma += reporte.calcularPromedio();
            count++;
        }
        
        return suma / count;
    }
    
    public List<ReporteDesempeño> getReportes() {
        return new ArrayList<>(reportes);
    }
}
