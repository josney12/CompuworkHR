/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package servicios;

import java.io.*;
import java.util.List;
import modelo.Empleado;
import modelo.Departamento;
import java.util.ArrayList;

public class DataService {
    private static final String EMPLEADOS_FILE = "empleados.dat";
    private static final String DEPARTAMENTOS_FILE = "departamentos.dat";

    public void guardarDatos(List<Empleado> empleados, List<Departamento> departamentos) {
        try (ObjectOutputStream oosEmp = new ObjectOutputStream(new FileOutputStream(EMPLEADOS_FILE));
             ObjectOutputStream oosDep = new ObjectOutputStream(new FileOutputStream(DEPARTAMENTOS_FILE))) {
            
            oosEmp.writeObject(empleados);
            oosDep.writeObject(departamentos);
            
        } catch (IOException e) {
            System.err.println("Error al guardar datos: " + e.getMessage());
        }
    }
    
    @SuppressWarnings("unchecked")
    public List<Empleado> cargarEmpleados() {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(EMPLEADOS_FILE))) {
            return (List<Empleado>) ois.readObject();
        } catch (IOException | ClassNotFoundException e) {
            System.err.println("Error al cargar empleados: " + e.getMessage());
            return new ArrayList<>();
        }
    }
    
    @SuppressWarnings("unchecked")
    public List<Departamento> cargarDepartamentos() {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(DEPARTAMENTOS_FILE))) {
            return (List<Departamento>) ois.readObject();
        } catch (IOException | ClassNotFoundException e) {
            System.err.println("Error al cargar departamentos: " + e.getMessage());
            return new ArrayList<>();
        }
    }
}