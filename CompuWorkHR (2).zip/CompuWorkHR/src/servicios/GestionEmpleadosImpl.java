/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package servicios;

import interfaces.IGestionEmpleados;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import modelo.Empleado;
import modelo.Departamento;
import modelo.EmpleadoPermanente;
import modelo.EmpleadoTemporal;
import excepciones.EmpleadoException;

public class GestionEmpleadosImpl implements IGestionEmpleados {
    private List<Empleado> empleados;
    private int nextId;
    
    public GestionEmpleadosImpl() {
        this.empleados = new ArrayList<>();
        this.nextId = 1;
    }

    @Override
    public void contratarEmpleado(Empleado empleado) throws EmpleadoException {
        if (empleado == null) {
            throw new EmpleadoException("El empleado no puede ser nulo");
        }
        
        if (empleado.getNombre() == null || empleado.getNombre().trim().isEmpty() ||
            empleado.getApellido() == null || empleado.getApellido().trim().isEmpty() ||
            empleado.getDni() == null || empleado.getDni().trim().isEmpty()) {
            throw new EmpleadoException("Nombre, apellido y DNI son campos requeridos");
        }
        
        boolean dniExiste = empleados.stream()
                .anyMatch(e -> e.getDni().equalsIgnoreCase(empleado.getDni()));
        
        if (dniExiste) {
            throw new EmpleadoException("Ya existe un empleado con este DNI");
        }
        
        empleado.setId(nextId++);
        empleados.add(empleado);
    }

    @Override
    public void despedirEmpleado(int idEmpleado) throws EmpleadoException {
        Empleado empleado = buscarEmpleado(idEmpleado);
        
        if (empleado.getDepartamento() != null) {
            empleado.getDepartamento().removerEmpleado(empleado);
        }
        
        empleados.remove(empleado);
    }

    @Override
    public void asignarDepartamento(int idEmpleado, Departamento departamento) throws EmpleadoException {
        Empleado empleado = buscarEmpleado(idEmpleado);
        
        if (empleado.getDepartamento() != null) {
            throw new EmpleadoException("El empleado ya está asignado a un departamento");
        }
        
        departamento.agregarEmpleado(empleado);
    }

    @Override
    public void cambiarDepartamento(int idEmpleado, Departamento nuevoDepartamento) throws EmpleadoException {
        Empleado empleado = buscarEmpleado(idEmpleado);
        
        if (empleado.getDepartamento() != null) {
            empleado.getDepartamento().removerEmpleado(empleado);
        }
        
        nuevoDepartamento.agregarEmpleado(empleado);
    }

    @Override
    public Empleado buscarEmpleado(int idEmpleado) throws EmpleadoException {
        return empleados.stream()
                .filter(e -> e.getId() == idEmpleado)
                .findFirst()
                .orElseThrow(() -> new EmpleadoException("Empleado no encontrado con ID: " + idEmpleado));
    }

    @Override
    public List<Empleado> listarEmpleados() {
        return new ArrayList<>(empleados);
    }

    @Override
    public List<Empleado> listarEmpleadosPorDepartamento(int idDepartamento) {
        return empleados.stream()
                .filter(e -> e.getDepartamento() != null && e.getDepartamento().getId() == idDepartamento)
                .collect(Collectors.toList());
    }

    @Override
    public void actualizarEmpleado(Empleado empleado) throws EmpleadoException {
        if (empleado == null) {
            throw new EmpleadoException("El empleado no puede ser nulo");
        }
        
        Empleado existente = buscarEmpleado(empleado.getId());
        
        if (empleado.getNombre() == null || empleado.getNombre().trim().isEmpty() ||
            empleado.getApellido() == null || empleado.getApellido().trim().isEmpty() ||
            empleado.getDni() == null || empleado.getDni().trim().isEmpty()) {
            throw new EmpleadoException("Nombre, apellido y DNI son campos requeridos");
        }
        
        boolean dniExiste = empleados.stream()
                .filter(e -> e.getId() != empleado.getId())
                .anyMatch(e -> e.getDni().equalsIgnoreCase(empleado.getDni()));
        
        if (dniExiste) {
            throw new EmpleadoException("Ya existe otro empleado con este DNI");
        }
        
        existente.setNombre(empleado.getNombre());
        existente.setApellido(empleado.getApellido());
        existente.setDni(empleado.getDni());
        existente.setFechaContratacion(empleado.getFechaContratacion());
        existente.setSalarioBase(empleado.getSalarioBase());
        
        if (existente instanceof EmpleadoPermanente && empleado instanceof EmpleadoPermanente) {
            EmpleadoPermanente epExistente = (EmpleadoPermanente) existente;
            EmpleadoPermanente epNuevo = (EmpleadoPermanente) empleado;
            
            epExistente.setBeneficiosAdicionales(epNuevo.getBeneficiosAdicionales());
            epExistente.setPorcentajeAntiguedad(epNuevo.getPorcentajeAntiguedad());
        } 
        else if (existente instanceof EmpleadoTemporal && empleado instanceof EmpleadoTemporal) {
            EmpleadoTemporal etExistente = (EmpleadoTemporal) existente;
            EmpleadoTemporal etNuevo = (EmpleadoTemporal) empleado;
            
            etExistente.setFechaFinContrato(etNuevo.getFechaFinContrato());
        }
    }
}