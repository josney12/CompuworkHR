/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class ReporteDesempeño {
    private int id;
    private Empleado empleado;
    private Date fechaEvaluacion;
    private List<Evaluacion> evaluaciones;
    private String comentariosGenerales;

    public ReporteDesempeño(int id, Empleado empleado, Date fechaEvaluacion, String comentariosGenerales) {
        this.id = id;
        this.empleado = empleado;
        this.fechaEvaluacion = fechaEvaluacion;
        this.comentariosGenerales = comentariosGenerales;
        this.evaluaciones = new ArrayList<>();
    }

    // Método corregido para agregar evaluaciones
    public void agregarEvaluacion(Evaluacion evaluacion) {
        if (evaluacion != null) {
            this.evaluaciones.add(evaluacion);
        }
    }

    // Getters
    public int getId() { return id; }
    public Empleado getEmpleado() { return empleado; }
    public Date getFechaEvaluacion() { return fechaEvaluacion; }
    public List<Evaluacion> getEvaluaciones() { return new ArrayList<>(evaluaciones); }
    public String getComentariosGenerales() { return comentariosGenerales; }

    // Método para calcular promedio
    public double calcularPromedio() {
        if (evaluaciones.isEmpty()) return 0;
        
        double suma = 0;
        for (Evaluacion eval : evaluaciones) {
            suma += eval.getPuntaje();
        }
        return suma / evaluaciones.size();
    }

    @Override
    public String toString() {
        return "Reporte ID: " + id + ", Empleado: " + empleado.getNombre() + 
               " " + empleado.getApellido() + ", Fecha: " + fechaEvaluacion + 
               ", Promedio: " + calcularPromedio();
    }
}