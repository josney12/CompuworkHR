/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;


import java.util.Date;

public class EmpleadoPermanente extends Empleado {
    private double beneficiosAdicionales;
    private double porcentajeAntiguedad;

    public EmpleadoPermanente(int id, String nombre, String apellido, String dni, 
                             Date fechaContratacion, double salarioBase, 
                             double beneficiosAdicionales, double porcentajeAntiguedad) {
        super(id, nombre, apellido, dni, fechaContratacion, salarioBase);
        this.beneficiosAdicionales = beneficiosAdicionales;
        this.porcentajeAntiguedad = porcentajeAntiguedad;
    }

    @Override
    public double calcularSalario() {
        return getSalarioBase() + beneficiosAdicionales + 
               (getSalarioBase() * porcentajeAntiguedad / 100);
    }

    public double getBeneficiosAdicionales() { 
        return beneficiosAdicionales; 
    }
    
    public void setBeneficiosAdicionales(double beneficiosAdicionales) {
        this.beneficiosAdicionales = beneficiosAdicionales;
    }
    
    public double getPorcentajeAntiguedad() { 
        return porcentajeAntiguedad; 
    }
    
    public void setPorcentajeAntiguedad(double porcentajeAntiguedad) {
        this.porcentajeAntiguedad = porcentajeAntiguedad;
    }
    
    @Override
    public String toString() {
        return super.toString() + ", Tipo: Permanente";
    }
}
