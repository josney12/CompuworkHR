/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

public class Evaluacion {
    private String criterio;
    private double puntaje;
    private String comentarios;

    public Evaluacion(String criterio, double puntaje, String comentarios) {
        this.criterio = criterio;
        this.puntaje = puntaje;
        this.comentarios = comentarios;
    }

    // Getters
    public String getCriterio() { return criterio; }
    public double getPuntaje() { return puntaje; }
    public String getComentarios() { return comentarios; }

    @Override
    public String toString() {
        return "Criterio: " + criterio + ", Puntaje: " + puntaje + 
               ", Comentarios: " + comentarios;
    }
}