/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

import java.util.Date;

public class EmpleadoTemporal extends Empleado {
    private Date fechaFinContrato;

    public EmpleadoTemporal(int id, String nombre, String apellido, String dni, 
                           Date fechaContratacion, double salarioBase, 
                           Date fechaFinContrato) {
        super(id, nombre, apellido, dni, fechaContratacion, salarioBase);
        this.fechaFinContrato = fechaFinContrato;
    }

    @Override
    public double calcularSalario() {
        return getSalarioBase(); // No tiene beneficios adicionales
    }

    public Date getFechaFinContrato() { return fechaFinContrato; }
    public void setFechaFinContrato(Date fechaFinContrato) {
        this.fechaFinContrato = fechaFinContrato;
    }
    
    @Override
    public String toString() {
        return super.toString() + ", Tipo: Temporal, Fin contrato: " + fechaFinContrato;
    }
}