/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;
import java.util.Date;

public abstract class Empleado {
    private int id;
    private String nombre;
    private String apellido;
    private String dni;
    private Date fechaContratacion;
    private double salarioBase;
    private Departamento departamento;

    public Empleado(int id, String nombre, String apellido, String dni, 
                   Date fechaContratacion, double salarioBase) {
        this.id = id;
        this.nombre = nombre;
        this.apellido = apellido;
        this.dni = dni;
        this.fechaContratacion = fechaContratacion;
        this.salarioBase = salarioBase;
    }

    // Getters y setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    
    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }
    
    public String getApellido() { return apellido; }
    public void setApellido(String apellido) { this.apellido = apellido; }
    
    public String getDni() { return dni; }
    public void setDni(String dni) { this.dni = dni; }
    
    public Date getFechaContratacion() { return fechaContratacion; }
    public void setFechaContratacion(Date fechaContratacion) { 
        this.fechaContratacion = fechaContratacion; 
    }
    
    public double getSalarioBase() { return salarioBase; }
    public void setSalarioBase(double salarioBase) { 
        this.salarioBase = salarioBase; 
    }
    
    public Departamento getDepartamento() { return departamento; }
    public void setDepartamento(Departamento departamento) { 
        this.departamento = departamento; 
    }

    public abstract double calcularSalario();
    
    @Override
    public String toString() {
        return "ID: " + id + ", Nombre: " + nombre + " " + apellido + 
               ", DNI: " + dni + ", Departamento: " + 
               (departamento != null ? departamento.getNombre() : "Sin asignar");
    }
}