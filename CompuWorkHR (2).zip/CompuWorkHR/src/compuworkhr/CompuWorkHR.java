/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package compuworkhr;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import modelo.Departamento;
import modelo.EmpleadoPermanente;
import modelo.EmpleadoTemporal;
import modelo.ReporteDesempeño;
import modelo.Evaluacion;
import servicios.GestionDepartamentosImpl;
import servicios.GestionEmpleadosImpl;
import servicios.ReporteService;
import excepciones.EmpleadoException;
import excepciones.DepartamentoException;
import modelo.Empleado;

public class CompuWorkHR {
    private static final GestionEmpleadosImpl gestionEmpleados = new GestionEmpleadosImpl();
    private static final GestionDepartamentosImpl gestionDepartamentos = new GestionDepartamentosImpl();
    private static final ReporteService reporteService = new ReporteService();
    private static final Scanner scanner = new Scanner(System.in);
    private static final SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
    private static final Logger logger = Logger.getLogger(CompuWorkHR.class.getName());

    public static void main(String[] args) {
        cargarDatosIniciales();
        mostrarMenuPrincipal();
    }
    
    private static void cargarDatosIniciales() {
        try {
            // Datos de ejemplo para pruebas
            Date hoy = new Date();
            
            Departamento depto1 = new Departamento(1, "Ventas", "Departamento de ventas");
            Departamento depto2 = new Departamento(2, "TI", "Tecnologías de la información");
            
            gestionDepartamentos.crearDepartamento(depto1);
            gestionDepartamentos.crearDepartamento(depto2);
            
            // Llamada corregida al constructor de EmpleadoPermanente
            EmpleadoPermanente emp1 = new EmpleadoPermanente(
                1,                     // id
                "Juan",                // nombre
                "Pérez",               // apellido
                "12345678",            // dni
                hoy,                   // fechaContratacion
                2500.0,                // salarioBase (double)
                300.0,                 // beneficiosAdicionales (double)
                5.0                    // porcentajeAntiguedad (double)
            );
            
            EmpleadoTemporal emp2 = new EmpleadoTemporal(
                2,                     // id
                "Ana",                 // nombre 
                "Gómez",               // apellido
                "87654321",            // dni
                hoy,                   // fechaContratacion
                2000.0,                // salarioBase (double)
                dateFormat.parse("31/12/2023") // fechaFinContrato
            );
            
            gestionEmpleados.contratarEmpleado(emp1);
            gestionEmpleados.contratarEmpleado(emp2);
            
            gestionEmpleados.asignarDepartamento(1, depto1);
            gestionEmpleados.asignarDepartamento(2, depto2);
            
            // Reportes de ejemplo
            ReporteDesempeño reporte1 = reporteService.crearReporte(emp1, hoy, "Buen desempeño en ventas");
            reporte1.agregarEvaluacion(new Evaluacion("Productividad", 8.5, "Cumple con los objetivos"));
            reporte1.agregarEvaluacion(new Evaluacion("Trabajo en equipo", 9.0, "Excelente colaborador"));
            
            ReporteDesempeño reporte2 = reporteService.crearReporte(emp2, hoy, "Progresando en TI");
            reporte2.agregarEvaluacion(new Evaluacion("Habilidades técnicas", 7.5, "Aprendiendo rápido"));
            reporte2.agregarEvaluacion(new Evaluacion("Puntualidad", 8.0, "Siempre a tiempo"));
            
        } catch (ParseException | EmpleadoException | DepartamentoException e) {
            logger.log(Level.SEVERE, "Error al cargar datos iniciales: {0}", e.getMessage());
        }
    }
    
    private static void mostrarMenuPrincipal() {
        boolean salir = false;
        
        while (!salir) {
            System.out.println("\n=== SISTEMA DE GESTIÓN COMPUWORK HR ===");
            System.out.println("1. Gestión de Empleados");
            System.out.println("2. Gestión de Departamentos");
            System.out.println("3. Reportes de Desempeño");
            System.out.println("4. Salir");
            System.out.print("Seleccione una opción: ");
            
            try {
                int opcion = Integer.parseInt(scanner.nextLine());
                
                switch (opcion) {
                    case 1 -> menuGestionEmpleados();
                    case 2 -> menuGestionDepartamentos();
                    case 3 -> menuReportesDesempeño();
                    case 4 -> salir = true;
                    default -> System.out.println("Opción no válida. Intente nuevamente.");
                }
            } catch (NumberFormatException e) {
                System.out.println("Por favor ingrese un número válido.");
            }
        }
        
        System.out.println("Saliendo del sistema...");
    }
    
    private static void menuGestionEmpleados() {
        boolean volver = false;
        
        while (!volver) {
            System.out.println("\n--- GESTIÓN DE EMPLEADOS ---");
            System.out.println("1. Contratar Empleado");
            System.out.println("2. Despedir Empleado");
            System.out.println("3. Asignar Departamento");
            System.out.println("4. Cambiar Departamento");
            System.out.println("5. Listar Empleados");
            System.out.println("6. Buscar Empleado");
            System.out.println("7. Actualizar Empleado");
            System.out.println("8. Volver al Menú Principal");
            System.out.print("Seleccione una opción: ");
            
            try {
                int opcion = Integer.parseInt(scanner.nextLine());
                
                switch (opcion) {
                    case 1 -> contratarEmpleado();
                    case 2 -> despedirEmpleado();
                    case 3 -> asignarDepartamento();
                    case 4 -> cambiarDepartamento();
                    case 5 -> listarEmpleados();
                    case 6 -> buscarEmpleado();
                    case 7 -> actualizarEmpleado();
                    case 8 -> volver = true;
                    default -> System.out.println("Opción no válida. Intente nuevamente.");
                }
            } catch (NumberFormatException e) {
                System.out.println("Por favor ingrese un número válido.");
            }
        }
    }
    
    private static void contratarEmpleado() {
        System.out.println("\n--- CONTRATAR NUEVO EMPLEADO ---");
        System.out.print("Tipo de empleado (1. Permanente / 2. Temporal): ");
        int tipo = Integer.parseInt(scanner.nextLine());
        
        System.out.print("Nombre: ");
        String nombre = scanner.nextLine();
        
        System.out.print("Apellido: ");
        String apellido = scanner.nextLine();
        
        System.out.print("DNI: ");
        String dni = scanner.nextLine();
        
        System.out.print("Fecha de contratación (dd/MM/yyyy): ");
        String fechaStr = scanner.nextLine();
        
        System.out.print("Salario base: ");
        double salarioBase = Double.parseDouble(scanner.nextLine());
        
        try {
            Date fechaContratacion = dateFormat.parse(fechaStr);
            
            if (tipo == 1) {
                System.out.print("Beneficios adicionales: ");
                double beneficios = Double.parseDouble(scanner.nextLine());
                
                System.out.print("Porcentaje de antigüedad: ");
                double antiguedad = Double.parseDouble(scanner.nextLine());
                
                EmpleadoPermanente empleado = new EmpleadoPermanente(0, nombre, apellido, dni, 
                                                                    fechaContratacion, salarioBase, 
                                                                    beneficios, antiguedad);
                gestionEmpleados.contratarEmpleado(empleado);
                System.out.println("Empleado permanente contratado con éxito!");
            } 
            else if (tipo == 2) {
                System.out.print("Fecha fin de contrato (dd/MM/yyyy): ");
                String fechaFinStr = scanner.nextLine();
                Date fechaFin = dateFormat.parse(fechaFinStr);
                
                EmpleadoTemporal empleado = new EmpleadoTemporal(0, nombre, apellido, dni, 
                                                                fechaContratacion, salarioBase, fechaFin);
                gestionEmpleados.contratarEmpleado(empleado);
                System.out.println("Empleado temporal contratado con éxito!");
            } 
            else {
                System.out.println("Tipo de empleado no válido.");
            }
        } catch (ParseException e) {
            System.out.println("Formato de fecha incorrecto. Use dd/MM/yyyy");
        } catch (EmpleadoException e) {
            System.out.println("Error al contratar empleado: " + e.getMessage());
        }
    }
    
    private static void despedirEmpleado() {
        System.out.println("\n--- DESPEDIR EMPLEADO ---");
        System.out.print("ID del empleado a despedir: ");
        int id = Integer.parseInt(scanner.nextLine());
        
        try {
            gestionEmpleados.despedirEmpleado(id);
            System.out.println("Empleado despedido con éxito.");
        } catch (EmpleadoException e) {
            System.out.println("Error al despedir empleado: " + e.getMessage());
        }
    }
    
    private static void asignarDepartamento() {
        System.out.println("\n--- ASIGNAR DEPARTAMENTO ---");
        System.out.print("ID del empleado: ");
        int idEmp = Integer.parseInt(scanner.nextLine());
        
        System.out.print("ID del departamento: ");
        int idDepto = Integer.parseInt(scanner.nextLine());
        
        try {
            Empleado emp = gestionEmpleados.buscarEmpleado(idEmp);
            Departamento depto = gestionDepartamentos.buscarDepartamento(idDepto);
            
            gestionEmpleados.asignarDepartamento(idEmp, depto);
            System.out.println("Empleado asignado al departamento con éxito!");
        } catch (EmpleadoException | DepartamentoException e) {
            System.out.println("Error al asignar departamento: " + e.getMessage());
        }
    }
    
    private static void cambiarDepartamento() {
        System.out.println("\n--- CAMBIAR DEPARTAMENTO ---");
        System.out.print("ID del empleado: ");
        int idEmp = Integer.parseInt(scanner.nextLine());
        
        System.out.print("ID del nuevo departamento: ");
        int idDepto = Integer.parseInt(scanner.nextLine());
        
        try {
            Empleado emp = gestionEmpleados.buscarEmpleado(idEmp);
            Departamento nuevoDepto = gestionDepartamentos.buscarDepartamento(idDepto);
            
            gestionEmpleados.cambiarDepartamento(idEmp, nuevoDepto);
            System.out.println("Departamento cambiado con éxito!");
        } catch (EmpleadoException | DepartamentoException e) {
            System.out.println("Error al cambiar departamento: " + e.getMessage());
        }
    }
    
    private static void listarEmpleados() {
        System.out.println("\n--- LISTADO DE EMPLEADOS ---");
        List<Empleado> empleados = gestionEmpleados.listarEmpleados();
        
        if (empleados.isEmpty()) {
            System.out.println("No hay empleados registrados.");
        } else {
            empleados.forEach(System.out::println);
        }
    }
    
    private static void buscarEmpleado() {
        System.out.println("\n--- BUSCAR EMPLEADO ---");
        System.out.print("ID del empleado: ");
        int id = Integer.parseInt(scanner.nextLine());
        
        try {
            Empleado emp = gestionEmpleados.buscarEmpleado(id);
            System.out.println("Empleado encontrado:");
            System.out.println(emp);
            
            if (emp.getDepartamento() != null) {
                System.out.println("Departamento: " + emp.getDepartamento().getNombre());
            }
            
            System.out.println("Salario total: $" + emp.calcularSalario());
        } catch (EmpleadoException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
    
    private static void actualizarEmpleado() {
        System.out.println("\n--- ACTUALIZAR EMPLEADO ---");
        System.out.print("ID del empleado a actualizar: ");
        int id = Integer.parseInt(scanner.nextLine());
        
        try {
            Empleado emp = gestionEmpleados.buscarEmpleado(id);
            
            System.out.println("Datos actuales:");
            System.out.println(emp);
            
            System.out.print("Nuevo nombre (" + emp.getNombre() + "): ");
            String nombre = scanner.nextLine();
            if (!nombre.isEmpty()) emp.setNombre(nombre);
            
            System.out.print("Nuevo apellido (" + emp.getApellido() + "): ");
            String apellido = scanner.nextLine();
            if (!apellido.isEmpty()) emp.setApellido(apellido);
            
            System.out.print("Nuevo DNI (" + emp.getDni() + "): ");
            String dni = scanner.nextLine();
            if (!dni.isEmpty()) emp.setDni(dni);
            
            System.out.print("Nuevo salario base (" + emp.getSalarioBase() + "): ");
            String salarioStr = scanner.nextLine();
            if (!salarioStr.isEmpty()) emp.setSalarioBase(Double.parseDouble(salarioStr));
            
            if (emp instanceof EmpleadoPermanente) {
                EmpleadoPermanente empPerm = (EmpleadoPermanente) emp;
                
                System.out.print("Nuevos beneficios adicionales (" + empPerm.getBeneficiosAdicionales() + "): ");
                String beneficiosStr = scanner.nextLine();
                if (!beneficiosStr.isEmpty()) 
                    empPerm.setBeneficiosAdicionales(Double.parseDouble(beneficiosStr));
                
                System.out.print("Nuevo porcentaje antigüedad (" + empPerm.getPorcentajeAntiguedad() + "%): ");
                String antiguedadStr = scanner.nextLine();
                if (!antiguedadStr.isEmpty()) 
                    empPerm.setPorcentajeAntiguedad(Double.parseDouble(antiguedadStr));
            } 
            else if (emp instanceof EmpleadoTemporal) {
                EmpleadoTemporal empTemp = (EmpleadoTemporal) emp;
                
                System.out.print("Nueva fecha fin de contrato (" + dateFormat.format(empTemp.getFechaFinContrato()) + "): ");
                String fechaStr = scanner.nextLine();
                if (!fechaStr.isEmpty()) 
                    empTemp.setFechaFinContrato(dateFormat.parse(fechaStr));
            }
            
            gestionEmpleados.actualizarEmpleado(emp);
            System.out.println("Empleado actualizado con éxito!");
            
        } catch (ParseException e) {
            System.out.println("Formato de fecha incorrecto. Use dd/MM/yyyy");
        } catch (EmpleadoException | NumberFormatException e) {
            System.out.println("Error al actualizar empleado: " + e.getMessage());
        }
    }
    
    private static void menuGestionDepartamentos() {
        boolean volver = false;
        
        while (!volver) {
            System.out.println("\n--- GESTIÓN DE DEPARTAMENTOS ---");
            System.out.println("1. Crear Departamento");
            System.out.println("2. Eliminar Departamento");
            System.out.println("3. Listar Departamentos");
            System.out.println("4. Buscar Departamento");
            System.out.println("5. Actualizar Departamento");
            System.out.println("6. Listar Empleados por Departamento");
            System.out.println("7. Volver al Menú Principal");
            System.out.print("Seleccione una opción: ");
            
            try {
                int opcion = Integer.parseInt(scanner.nextLine());
                
                switch (opcion) {
                    case 1 -> crearDepartamento();
                    case 2 -> eliminarDepartamento();
                    case 3 -> listarDepartamentos();
                    case 4 -> buscarDepartamento();
                    case 5 -> actualizarDepartamento();
                    case 6 -> listarEmpleadosPorDepto();
                    case 7 -> volver = true;
                    default -> System.out.println("Opción no válida. Intente nuevamente.");
                }
            } catch (NumberFormatException e) {
                System.out.println("Por favor ingrese un número válido.");
            }
        }
    }
    
    private static void crearDepartamento() {
        System.out.println("\n--- CREAR DEPARTAMENTO ---");
        System.out.print("Nombre: ");
        String nombre = scanner.nextLine();
        
        System.out.print("Descripción: ");
        String descripcion = scanner.nextLine();
        
        try {
            Departamento depto = new Departamento(0, nombre, descripcion);
            gestionDepartamentos.crearDepartamento(depto);
            System.out.println("Departamento creado con éxito!");
        } catch (DepartamentoException e) {
            System.out.println("Error al crear departamento: " + e.getMessage());
        }
    }
    
    private static void eliminarDepartamento() {
        System.out.println("\n--- ELIMINAR DEPARTAMENTO ---");
        System.out.print("ID del departamento a eliminar: ");
        int id = Integer.parseInt(scanner.nextLine());
        
        try {
            gestionDepartamentos.eliminarDepartamento(id);
            System.out.println("Departamento eliminado con éxito.");
        } catch (DepartamentoException e) {
            System.out.println("Error al eliminar departamento: " + e.getMessage());
        }
    }
    
    private static void listarDepartamentos() {
        System.out.println("\n--- LISTADO DE DEPARTAMENTOS ---");
        List<Departamento> departamentos = gestionDepartamentos.listarDepartamentos();
        
        if (departamentos.isEmpty()) {
            System.out.println("No hay departamentos registrados.");
        } else {
            departamentos.forEach(System.out::println);
        }
    }
    
    private static void buscarDepartamento() {
        System.out.println("\n--- BUSCAR DEPARTAMENTO ---");
        System.out.print("ID del departamento: ");
        int id = Integer.parseInt(scanner.nextLine());
        
        try {
            Departamento depto = gestionDepartamentos.buscarDepartamento(id);
            System.out.println("Departamento encontrado:");
            System.out.println(depto);
            
            System.out.println("\nEmpleados en este departamento:");
            List<Empleado> empleados = gestionEmpleados.listarEmpleadosPorDepartamento(id);
            
            if (empleados.isEmpty()) {
                System.out.println("No hay empleados en este departamento.");
            } else {
                empleados.forEach(System.out::println);
            }
        } catch (DepartamentoException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
    
    private static void actualizarDepartamento() {
        System.out.println("\n--- ACTUALIZAR DEPARTAMENTO ---");
        System.out.print("ID del departamento a actualizar: ");
        int id = Integer.parseInt(scanner.nextLine());
        
        try {
            Departamento depto = gestionDepartamentos.buscarDepartamento(id);
            
            System.out.println("Datos actuales:");
            System.out.println(depto);
            
            System.out.print("Nuevo nombre (" + depto.getNombre() + "): ");
            String nombre = scanner.nextLine();
            if (!nombre.isEmpty()) depto.setNombre(nombre);
            
            System.out.print("Nueva descripción (" + depto.getDescripcion() + "): ");
            String descripcion = scanner.nextLine();
            if (!descripcion.isEmpty()) depto.setDescripcion(descripcion);
            
            gestionDepartamentos.actualizarDepartamento(depto);
            System.out.println("Departamento actualizado con éxito!");
            
        } catch (DepartamentoException e) {
            System.out.println("Error al actualizar departamento: " + e.getMessage());
        }
    }
    
    private static void listarEmpleadosPorDepto() {
        System.out.println("\n--- EMPLEADOS POR DEPARTAMENTO ---");
        System.out.print("ID del departamento: ");
        int id = Integer.parseInt(scanner.nextLine());
        
        try {
            Departamento depto = gestionDepartamentos.buscarDepartamento(id);
            System.out.println("Departamento: " + depto.getNombre());
            
            List<Empleado> empleados = gestionEmpleados.listarEmpleadosPorDepartamento(id);
            
            if (empleados.isEmpty()) {
                System.out.println("No hay empleados en este departamento.");
            } else {
                System.out.println("\nLista de empleados:");
                empleados.forEach(System.out::println);
                
                // Calcular estadísticas
                double totalSalarios = empleados.stream()
                        .mapToDouble(Empleado::calcularSalario)
                        .sum();
                
                System.out.printf("\nTotal empleados: %d, Total salarios: $%.2f, Promedio: $%.2f%n",
                        empleados.size(), totalSalarios, totalSalarios / empleados.size());
            }
        } catch (DepartamentoException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
    
    private static void menuReportesDesempeño() {
        boolean volver = false;
        
        while (!volver) {
            System.out.println("\n--- REPORTES DE DESEMPEÑO ---");
            System.out.println("1. Crear Reporte");
            System.out.println("2. Agregar Evaluación");
            System.out.println("3. Ver Reportes por Empleado");
            System.out.println("4. Ver Reportes por Departamento");
            System.out.println("5. Estadísticas de Departamento");
            System.out.println("6. Volver al Menú Principal");
            System.out.print("Seleccione una opción: ");
            
            try {
                int opcion = Integer.parseInt(scanner.nextLine());
                
                switch (opcion) {
                    case 1 -> crearReporte();
                    case 2 -> agregarEvaluacion();
                    case 3 -> verReportesEmpleado();
                    case 4 -> verReportesDepartamento();
                    case 5 -> estadisticasDepartamento();
                    case 6 -> volver = true;
                    default -> System.out.println("Opción no válida. Intente nuevamente.");
                }
            } catch (NumberFormatException e) {
                System.out.println("Por favor ingrese un número válido.");
            }
        }
    }
    
    private static void crearReporte() {
        System.out.println("\n--- CREAR REPORTE ---");
        System.out.print("ID del empleado: ");
        int idEmp = Integer.parseInt(scanner.nextLine());
        
        System.out.print("Fecha de evaluación (dd/MM/yyyy): ");
        String fechaStr = scanner.nextLine();
        
        System.out.print("Comentarios generales: ");
        String comentarios = scanner.nextLine();
        
        try {
            Empleado emp = gestionEmpleados.buscarEmpleado(idEmp);
            Date fecha = dateFormat.parse(fechaStr);
            
            ReporteDesempeño reporte = reporteService.crearReporte(emp, fecha, comentarios);
            System.out.println("Reporte creado con ID: " + reporte.getId());
            
            // Opción para agregar evaluaciones inmediatamente
            System.out.print("¿Desea agregar evaluaciones ahora? (S/N): ");
            String respuesta = scanner.nextLine();
            
            if (respuesta.equalsIgnoreCase("S")) {
                agregarEvaluaciones(reporte);
            }
            
        } catch (ParseException e) {
            System.out.println("Formato de fecha incorrecto. Use dd/MM/yyyy");
        } catch (EmpleadoException e) {
            System.out.println("Error al crear reporte: " + e.getMessage());
        }
    }
    
    private static void agregarEvaluaciones(ReporteDesempeño reporte) {
        boolean continuar = true;
        
        while (continuar) {
            System.out.println("\n--- AGREGAR EVALUACIÓN ---");
            System.out.print("Criterio: ");
            String criterio = scanner.nextLine();
            
            System.out.print("Puntaje (0-10): ");
            double puntaje = Double.parseDouble(scanner.nextLine());
            
            System.out.print("Comentarios: ");
            String comentarios = scanner.nextLine();
            
            reporte.agregarEvaluacion(new Evaluacion(criterio, puntaje, comentarios));
            System.out.println("Evaluación agregada al reporte.");
            
            System.out.print("¿Agregar otra evaluación? (S/N): ");
            String respuesta = scanner.nextLine();
            continuar = respuesta.equalsIgnoreCase("S");
        }
    }
    
    private static void agregarEvaluacion() {
        System.out.println("\n--- AGREGAR EVALUACIÓN A REPORTE ---");
        System.out.print("ID del reporte: ");
        int idReporte = Integer.parseInt(scanner.nextLine());
        
        try {
            ReporteDesempeño reporte = reporteService.getReportes().stream()
                    .filter(r -> r.getId() == idReporte)
                    .findFirst()
                    .orElseThrow(() -> new Exception("Reporte no encontrado"));
            
            agregarEvaluaciones(reporte);
            
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
    
    private static void verReportesEmpleado() {
        System.out.println("\n--- REPORTES POR EMPLEADO ---");
        System.out.print("ID del empleado: ");
        int idEmp = Integer.parseInt(scanner.nextLine());
        
        try {
            Empleado emp = gestionEmpleados.buscarEmpleado(idEmp);
            List<ReporteDesempeño> reportes = reporteService.generarReportesIndividuales(emp);
            
            System.out.println("\nReportes para " + emp.getNombre() + " " + emp.getApellido() + ":");
            
            if (reportes.isEmpty()) {
                System.out.println("No hay reportes para este empleado.");
            } else {
                reportes.forEach(r -> {
                    System.out.println("\n" + r);
                    System.out.println("Comentarios: " + r.getComentariosGenerales());
                    System.out.println("Evaluaciones:");
                    r.getEvaluaciones().forEach(System.out::println);
                });
            }
        } catch (EmpleadoException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
    
    private static void verReportesDepartamento() {
        System.out.println("\n--- REPORTES POR DEPARTAMENTO ---");
        System.out.print("ID del departamento: ");
        int idDepto = Integer.parseInt(scanner.nextLine());
        
        try {
            Departamento depto = gestionDepartamentos.buscarDepartamento(idDepto);
            List<ReporteDesempeño> reportes = reporteService.generarReportesDepartamentales(idDepto);
            
            System.out.println("\nReportes para el departamento " + depto.getNombre() + ":");
            
            if (reportes.isEmpty()) {
                System.out.println("No hay reportes para este departamento.");
            } else {
                reportes.forEach(r -> {
                    System.out.println("\n" + r);
                    System.out.println("Empleado: " + r.getEmpleado().getNombre() + " " + r.getEmpleado().getApellido());
                    System.out.println("Promedio: " + r.calcularPromedio());
                });
            }
        } catch (DepartamentoException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
    
    private static void estadisticasDepartamento() {
        System.out.println("\n--- ESTADÍSTICAS DE DEPARTAMENTO ---");
        System.out.print("ID del departamento: ");
        int idDepto = Integer.parseInt(scanner.nextLine());
        
        try {
            Departamento depto = gestionDepartamentos.buscarDepartamento(idDepto);
            double promedio = reporteService.calcularPromedioDepartamento(idDepto);
            
            System.out.println("\nEstadísticas para " + depto.getNombre() + ":");
            System.out.printf("Promedio de desempeño: %.2f/10%n", promedio);
            
            // Clasificación cualitativa
            if (promedio >= 9) {
                System.out.println("Desempeño: Excelente");
            } else if (promedio >= 7) {
                System.out.println("Desempeño: Bueno");
            } else if (promedio >= 5) {
                System.out.println("Desempeño: Aceptable");
            } else {
                System.out.println("Desempeño: Necesita mejora");
            }
            
        } catch (DepartamentoException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}                                                                                                                                                    