/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package interfaces;

import java.util.List;
import modelo.Empleado;
import modelo.Departamento;
import excepciones.EmpleadoException;

public interface IGestionEmpleados {
    void contratarEmpleado(Empleado empleado) throws EmpleadoException;
    void despedirEmpleado(int idEmpleado) throws EmpleadoException;
    void asignarDepartamento(int idEmpleado, Departamento departamento) throws EmpleadoException;
    void cambiarDepartamento(int idEmpleado, Departamento nuevoDepartamento) throws EmpleadoException;
    Empleado buscarEmpleado(int idEmpleado) throws EmpleadoException;
    List<Empleado> listarEmpleados();
    List<Empleado> listarEmpleadosPorDepartamento(int idDepartamento);
    void actualizarEmpleado(Empleado empleado) throws EmpleadoException;
}