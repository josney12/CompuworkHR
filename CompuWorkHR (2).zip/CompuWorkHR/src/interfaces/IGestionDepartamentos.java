/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package interfaces;

import java.util.List;
import modelo.Departamento;
import excepciones.DepartamentoException;

public interface IGestionDepartamentos {
    void crearDepartamento(Departamento departamento) throws DepartamentoException;
    void eliminarDepartamento(int id) throws DepartamentoException;
    Departamento buscarDepartamento(int id) throws DepartamentoException;
    List<Departamento> listarDepartamentos();
    void actualizarDepartamento(Departamento departamento) throws DepartamentoException;
}
